#!/usr/bin/env bash
set -eu -o pipefail

#=====================================================================
# change the below values accordingly
#=====================================================================
MONGO_HOST="127.0.0.1"
MONGO_PORT="27017"
MONGO_USER="root"
MONGO_PASSWORD="password"
MONGO_AUTH_DB="admin"
#=====================================================================
